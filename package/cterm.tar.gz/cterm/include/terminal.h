#ifndef TERMINAL_H
#define TERMINAL_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdint.h>
#include <stdbool.h>

/* ── dimensions ── */
#define MAX_COLS        220
#define MAX_ROWS        50
#define SCROLLBACK      4000
#define MAX_TABS        16

/* ── colours (Dracula-ish palette) ── */
#define COL_BG          0xFF282A36
#define COL_FG          0xFFF8F8F2
#define COL_CURSOR      0xFFF1FA8C
#define COL_SEL         0x446272A4
#define COL_TAB_ACT     0xFF44475A
#define COL_TAB_INACT   0xFF21222C
#define COL_TAB_TEXT    0xFFF8F8F2
#define COL_BORDER      0xFF6272A4

/* ANSI 16-colour palette */
static const uint32_t ANSI_PALETTE[16] = {
    0xFF21222C, 0xFFFF5555, 0xFF50FA7B, 0xFFF1FA8C,
    0xFF6272A4, 0xFFFF79C6, 0xFF8BE9FD, 0xFFF8F8F2,
    0xFF44475A, 0xFFFF6E67, 0xFF5AF78E, 0xFFF4F99D,
    0xFF6272A4, 0xFFFF92D0, 0xFF9AEDFE, 0xFFFFFFFF,
};

typedef struct {
    uint32_t fg;       /* ARGB */
    uint32_t bg;
    bool bold;
    bool italic;
    bool underline;
    bool blink;
    bool reverse;
    bool invisible;
} CellAttr;

typedef struct {
    uint32_t codepoint;   /* unicode codepoint */
    CellAttr attr;
    bool dirty;
} Cell;

typedef struct {
    Cell cells[MAX_COLS];
    bool soft_wrap;     /* wrapped from previous line */
} Row;

/* ── PTY / process handle ── */
#ifdef _WIN32
#include <windows.h>
typedef struct {
    HANDLE hProcess;
    HANDLE hThread;
    HANDLE hPipeIn;   /* write to child stdin  */
    HANDLE hPipeOut;  /* read  from child stdout */
    HPCON hPcon;
} PtyHandle;
#else
#include <unistd.h>
typedef struct {
    pid_t  pid;
    int    master_fd;
} PtyHandle;
#endif

/* ── escape-sequence parser state ── */
typedef enum {
    PS_GROUND,
    PS_ESC,
    PS_CSI,
    PS_OSC,
    PS_DCS,
    PS_UTF8,
} ParseState;

#define MAX_PARAMS 16
#define MAX_OSC    512

typedef struct {
    ParseState state;
    int  params[MAX_PARAMS];
    int  nparams;
    char intermediate[4];
    int  ninter;
    char osc_buf[MAX_OSC];
    int  osc_len;
    /* UTF-8 accumulator */
    uint32_t utf8_acc;
    int      utf8_need;
    /* private marker: '?' '<' '>' '=' */
    char priv;
} VTParser;

/* ── tab ── */
typedef struct {
    char     title[256];
    PtyHandle pty;
    VTParser  parser;

    /* screen buffer: [scrollback + rows] */
    Row   *lines;          /* heap array, size = SCROLLBACK+MAX_ROWS */
    int    total_lines;    /* allocated rows (SCROLLBACK+MAX_ROWS) */
    int    view_top;       /* first visible line index in lines[] */
    int    scroll_offset;  /* lines scrolled back (0 = bottom) */

    /* cursor */
    int  cur_row, cur_col; /* relative to view_top */
    bool cur_visible;
    CellAttr cur_attr;

    /* saved cursor */
    int  saved_row, saved_col;
    CellAttr saved_attr;

    /* scroll region */
    int scroll_top, scroll_bot; /* 0-based row indices within viewport */

    /* misc modes */
    bool mode_insert;
    bool mode_origin;
    bool mode_auto_wrap;
    bool mode_alt_screen;

    /* alternate screen */
    Row  *alt_lines;
    int   alt_cur_row, alt_cur_col;

    /* selection */
    int sel_start_row, sel_start_col;
    int sel_end_row,   sel_end_col;
    bool selecting;
    bool has_selection;

    bool alive;
    int  cols, rows;   /* current size */
} Tab;

/* ── app ── */
typedef struct {
    SDL_Window   *win;
    SDL_Renderer *ren;
    TTF_Font     *font;
    TTF_Font     *font_bold;

    int font_w, font_h;     /* cell size in pixels */
    int win_w,  win_h;

    int tab_bar_h;          /* pixel height of tab bar */
    int padding;

    Tab  *tabs[MAX_TABS];
    int   ntabs;
    int   active;

    bool running;
    bool blink_on;
    uint32_t last_blink;

    /* clipboard */
    char *clipboard;

    /* scrollbar */
    bool scrollbar_drag;
    int  scrollbar_drag_y;
} App;

/* ── API ── */
App  *app_create(void);
void  app_destroy(App *a);
void  app_run(App *a);

Tab  *tab_create(App *a, const char *shell);
void  tab_destroy(Tab *t);
void  tab_resize(Tab *t, int cols, int rows);
void  tab_write(Tab *t, const uint8_t *data, int len);
void  tab_process_input(Tab *t, const char *data, int len);

void  pty_spawn(PtyHandle *p, const char *shell, int cols, int rows);
void  pty_resize(PtyHandle *p, int cols, int rows);
int   pty_read(PtyHandle *p, uint8_t *buf, int bufsz);
int   pty_write(PtyHandle *p, const uint8_t *data, int len);
void  pty_close(PtyHandle *p);

void  vt_init(VTParser *p);
void  vt_process(Tab *t, uint8_t c);

void  render_frame(App *a);
Cell *get_cell_pub(Tab *t, int r, int c);

#endif /* TERMINAL_H */
