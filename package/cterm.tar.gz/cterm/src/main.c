#include "terminal.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/* expose cell getter for render.c */
Cell *get_cell_pub(Tab *t, int r, int c){
    if(r<0||r>=t->rows||c<0||c>=t->cols) return NULL;
    return &t->lines[t->view_top+r].cells[c];
}

/* ════════════════════════════════════════════════
   Tab
   ════════════════════════════════════════════════ */
Tab *tab_create(App *a, const char *shell){
    Tab *t=(Tab*)calloc(1,sizeof(Tab));
    t->total_lines=SCROLLBACK+MAX_ROWS;
    t->lines=(Row*)calloc(t->total_lines,sizeof(Row));
    t->alt_lines=(Row*)calloc(MAX_ROWS,sizeof(Row));

    /* compute initial cols/rows from window size */
    int sb_w=10;
    t->cols=(a->win_w - 2*a->padding - sb_w)/a->font_w;
    t->rows=(a->win_h - a->tab_bar_h - 2*a->padding)/a->font_h;
    if(t->cols<1)t->cols=1;
    if(t->rows<1)t->rows=1;
    if(t->cols>MAX_COLS)t->cols=MAX_COLS;
    if(t->rows>MAX_ROWS)t->rows=MAX_ROWS;

    t->view_top=SCROLLBACK;
    t->scroll_offset=0;
    t->cur_visible=true;
    t->mode_auto_wrap=true;
    t->scroll_top=0;
    t->scroll_bot=t->rows-1;

    /* blank all lines */
    for(int i=0;i<t->total_lines;i++)
        for(int c=0;c<MAX_COLS;c++){
            t->lines[i].cells[c].codepoint=' ';
            t->lines[i].cells[c].attr.fg=COL_FG;
        }

    vt_init(&t->parser);
    t->cur_attr.fg=COL_FG;

    /* default title */
    snprintf(t->title,sizeof(t->title),"Terminal");

    pty_spawn(&t->pty, shell, t->cols, t->rows);
    t->alive=true;
    return t;
}

void tab_destroy(Tab *t){
    pty_close(&t->pty);
    free(t->lines);
    free(t->alt_lines);
    free(t);
}

void tab_resize(Tab *t, int cols, int rows){
    if(cols==t->cols && rows==t->rows) return;
    if(cols<1)cols=1; if(rows<1)rows=1;
    if(cols>MAX_COLS)cols=MAX_COLS;
    if(rows>MAX_ROWS)rows=MAX_ROWS;
    t->cols=cols; t->rows=rows;
    t->scroll_top=0; t->scroll_bot=rows-1;
    if(t->cur_row>=rows) t->cur_row=rows-1;
    if(t->cur_col>=cols) t->cur_col=cols-1;
    pty_resize(&t->pty,cols,rows);
}

/* ── read PTY output and feed to VT parser ── */
static void tab_poll(Tab *t){
    uint8_t buf[4096];
    int n=pty_read(&t->pty,buf,sizeof(buf));
    if(n<0){ t->alive=false; return; }
    for(int i=0;i<n;i++) vt_process(t,buf[i]);
}

/* ════════════════════════════════════════════════
   App
   ════════════════════════════════════════════════ */
App *app_create(void){
    if(SDL_Init(SDL_INIT_VIDEO)<0){ fprintf(stderr,"SDL_Init: %s\n",SDL_GetError()); return NULL; }
    if(TTF_Init()<0){ fprintf(stderr,"TTF_Init: %s\n",TTF_GetError()); return NULL; }

    App *a=(App*)calloc(1,sizeof(App));
    a->padding=4;
    a->tab_bar_h=28;

    /* Window */
    a->win_w=1000; a->win_h=650;
    a->win=SDL_CreateWindow("cterm",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        a->win_w, a->win_h,
        SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI);
    if(!a->win){ fprintf(stderr,"SDL_CreateWindow: %s\n",SDL_GetError()); free(a); return NULL; }

    a->ren=SDL_CreateRenderer(a->win,-1,
        SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);
    if(!a->ren){
        a->ren=SDL_CreateRenderer(a->win,-1,SDL_RENDERER_SOFTWARE);
    }
    SDL_SetRenderDrawBlendMode(a->ren,SDL_BLENDMODE_BLEND);

    /* Font: try several common monospace fonts */
    const char *font_paths[]={
#ifdef _WIN32
        "C:/Windows/Fonts/consola.ttf",
        "C:/Windows/Fonts/cour.ttf",
        "C:/Windows/Fonts/lucon.ttf",
#else
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf",
        "/usr/share/fonts/truetype/freefont/FreeMono.ttf",
        "/usr/share/fonts/TTF/DejaVuSansMono.ttf",
        "/usr/share/fonts/dejavu/DejaVuSansMono.ttf",
        "/usr/share/fonts/truetype/ubuntu/UbuntuMono-R.ttf",
        "/usr/share/fonts/truetype/noto/NotoMono-Regular.ttf",
#endif
        NULL
    };
    int font_size=15;
    for(int i=0;font_paths[i];i++){
        a->font=TTF_OpenFont(font_paths[i],font_size);
        if(a->font){
            a->font_bold=TTF_OpenFont(font_paths[i],font_size);
            if(a->font_bold) TTF_SetFontStyle(a->font_bold,TTF_STYLE_BOLD);
            fprintf(stderr,"Font loaded: %s\n",font_paths[i]);
            break;
        }
    }
    if(!a->font){
        fprintf(stderr,"Warning: no monospace font found, text will be absent.\n");
        a->font_w=8; a->font_h=16;
    } else {
        TTF_SizeUTF8(a->font,"M",&a->font_w,&a->font_h);
        if(a->font_w<1)a->font_w=8;
        if(a->font_h<1)a->font_h=16;
    }
    fprintf(stderr,"Cell size: %dx%d\n",a->font_w,a->font_h);

    a->blink_on=true;
    a->last_blink=SDL_GetTicks();
    a->running=true;

    /* first tab */
    Tab *t=tab_create(a,NULL);
    a->tabs[0]=t; a->ntabs=1; a->active=0;

    SDL_StartTextInput();
    return a;
}

void app_destroy(App *a){
    SDL_StopTextInput();
    for(int i=0;i<a->ntabs;i++) tab_destroy(a->tabs[i]);
    if(a->font)      TTF_CloseFont(a->font);
    if(a->font_bold) TTF_CloseFont(a->font_bold);
    if(a->clipboard) free(a->clipboard);
    SDL_DestroyRenderer(a->ren);
    SDL_DestroyWindow(a->win);
    TTF_Quit();
    SDL_Quit();
    free(a);
}

/* ── new tab ── */
static void new_tab(App *a){
    if(a->ntabs>=MAX_TABS) return;
    Tab *t=tab_create(a,NULL);
    a->tabs[a->ntabs++]=t;
    a->active=a->ntabs-1;
}

/* ── close tab ── */
static void close_tab(App *a, int idx){
    if(a->ntabs<=1){ a->running=false; return; }
    tab_destroy(a->tabs[idx]);
    for(int i=idx;i<a->ntabs-1;i++) a->tabs[i]=a->tabs[i+1];
    a->ntabs--;
    if(a->active>=a->ntabs) a->active=a->ntabs-1;
}

/* ── resize all tabs ── */
static void resize_all(App *a){
    int sb_w=10;
    int cols=(a->win_w - 2*a->padding - sb_w)/a->font_w;
    int rows=(a->win_h - a->tab_bar_h - 2*a->padding)/a->font_h;
    for(int i=0;i<a->ntabs;i++) tab_resize(a->tabs[i],cols,rows);
}

/* ── selection copy ── */
static void copy_selection(App *a){
    Tab *t=a->tabs[a->active];
    if(!t->has_selection) return;
    int sr=t->sel_start_row, sc=t->sel_start_col;
    int er=t->sel_end_row,   ec=t->sel_end_col;
    if(sr>er||(sr==er&&sc>ec)){
        int tr=sr,tc=sc; sr=er;sc=ec; er=tr;ec=tc;
    }
    /* build string */
    int cap=4096; char *buf=(char*)malloc(cap); int pos=0;
    for(int r=sr;r<=er;r++){
        int c0=(r==sr)?sc:0;
        int c1=(r==er)?ec:t->cols-1;
        int abs=t->view_top+r-t->scroll_offset;
        if(abs<0||abs>=t->total_lines) continue;
        Row *row=&t->lines[abs];
        for(int c=c0;c<=c1;c++){
            uint32_t cp=row->cells[c].codepoint;
            if(!cp||cp==' '){ if(pos<cap-2) buf[pos++]=' '; continue; }
            /* encode UTF-8 */
            char tmp[5]={0};
            if(cp<0x80) tmp[0]=(char)cp;
            else if(cp<0x800){ tmp[0]=(char)(0xC0|(cp>>6)); tmp[1]=(char)(0x80|(cp&0x3F)); }
            else if(cp<0x10000){
                tmp[0]=(char)(0xE0|(cp>>12));
                tmp[1]=(char)(0x80|((cp>>6)&0x3F));
                tmp[2]=(char)(0x80|(cp&0x3F));
            }
            for(int k=0;k<4&&tmp[k];k++) if(pos<cap-2) buf[pos++]=tmp[k];
        }
        if(r<er && pos<cap-2) buf[pos++]='\n';
    }
    buf[pos]='\0';
    SDL_SetClipboardText(buf);
    free(buf);
}

/* ── handle keyboard ── */
static void handle_key(App *a, SDL_KeyboardEvent *ev){
    Tab *t=a->tabs[a->active];
    SDL_Keymod mod=ev->keysym.mod;
    SDL_Keycode sym=ev->keysym.sym;

    bool ctrl =(mod&KMOD_CTRL)!=0;
    bool shift=(mod&KMOD_SHIFT)!=0;
    bool alt  =(mod&KMOD_ALT)!=0;

    /* ── app shortcuts ── */
    if(ctrl && shift){
        if(sym==SDLK_t){ new_tab(a); return; }
        if(sym==SDLK_w){ close_tab(a,a->active); return; }
        if(sym==SDLK_c){ copy_selection(a); return; }
        if(sym==SDLK_v){
            char *clip=SDL_GetClipboardText();
            if(clip){ pty_write(&t->pty,(uint8_t*)clip,(int)strlen(clip)); SDL_free(clip); }
            return;
        }
        if(sym==SDLK_TAB){
            a->active=(a->active+1)%a->ntabs; return;
        }
    }
    /* Ctrl+1..9 switch tab */
    if(ctrl && sym>=SDLK_1 && sym<=SDLK_9){
        int idx=sym-SDLK_1;
        if(idx<a->ntabs){ a->active=idx; return; }
    }

    /* ── map to escape sequences ── */
    const char *seq=NULL;
    char buf[16]={0};
    switch(sym){
    case SDLK_RETURN:  seq="\r"; break;
    case SDLK_KP_ENTER:seq="\r"; break;
    case SDLK_BACKSPACE: seq="\x7f"; break;
    case SDLK_DELETE:  seq="\x1b[3~"; break;
    case SDLK_INSERT:  seq="\x1b[2~"; break;
    case SDLK_HOME:    seq= shift?"\x1b[1;2H":"\x1b[H"; break;
    case SDLK_END:     seq= shift?"\x1b[1;2F":"\x1b[F"; break;
    case SDLK_PAGEUP:
        if(shift){ t->scroll_offset+=t->rows/2; int max=t->view_top; if(t->scroll_offset>max)t->scroll_offset=max; return; }
        seq="\x1b[5~"; break;
    case SDLK_PAGEDOWN:
        if(shift){ t->scroll_offset-=t->rows/2; if(t->scroll_offset<0)t->scroll_offset=0; return; }
        seq="\x1b[6~"; break;
    case SDLK_UP:      seq="\x1b[A"; break;
    case SDLK_DOWN:    seq="\x1b[B"; break;
    case SDLK_RIGHT:   seq="\x1b[C"; break;
    case SDLK_LEFT:    seq="\x1b[D"; break;
    case SDLK_F1:  seq="\x1bOP"; break;
    case SDLK_F2:  seq="\x1bOQ"; break;
    case SDLK_F3:  seq="\x1bOR"; break;
    case SDLK_F4:  seq="\x1bOS"; break;
    case SDLK_F5:  seq="\x1b[15~"; break;
    case SDLK_F6:  seq="\x1b[17~"; break;
    case SDLK_F7:  seq="\x1b[18~"; break;
    case SDLK_F8:  seq="\x1b[19~"; break;
    case SDLK_F9:  seq="\x1b[20~"; break;
    case SDLK_F10: seq="\x1b[21~"; break;
    case SDLK_F11: seq="\x1b[23~"; break;
    case SDLK_F12: seq="\x1b[24~"; break;
    case SDLK_TAB:
        seq=shift?"\x1b[Z":"\t"; break;
    case SDLK_ESCAPE: seq="\x1b"; break;
    default:
        if(ctrl && sym>=SDLK_a && sym<=SDLK_z){
            buf[0]=(char)(sym-SDLK_a+1); seq=buf; break;
        }
        if(ctrl && sym==SDLK_BACKSLASH){ buf[0]=0x1c; seq=buf; break; }
        if(ctrl && sym==SDLK_RIGHTBRACKET){ buf[0]=0x1d; seq=buf; break; }
        if(ctrl && sym==SDLK_6){ buf[0]=0x1e; seq=buf; break; }
        if(alt && sym>=0x20 && sym<0x7f){
            buf[0]='\x1b'; buf[1]=(char)sym; seq=buf; break;
        }
        break;
    }
    if(seq) pty_write(&t->pty,(uint8_t*)seq,(int)strlen(seq));
}

/* ── mouse → (row,col) in viewport ── */
static void screen_to_cell(App *a, int mx, int my, int *row, int *col){
    Tab *t=a->tabs[a->active];
    int x0=a->padding, y0=a->tab_bar_h+a->padding;
    *col=(mx-x0)/a->font_w;
    *row=(my-y0)/a->font_h;
    if(*col<0)*col=0; if(*col>=t->cols)*col=t->cols-1;
    if(*row<0)*row=0; if(*row>=t->rows)*row=t->rows-1;
}

/* ── click on tab bar ── */
static void handle_tab_bar_click(App *a, int mx){
    int tab_w=a->win_w/a->ntabs;
    if(tab_w>200) tab_w=200;

    /* "+" button */
    if(mx>=a->ntabs*tab_w){
        new_tab(a); return;
    }

    int idx=mx/tab_w;
    if(idx<0||idx>=a->ntabs) return;

    /* close button? */
    int close_x=idx*tab_w+tab_w-1-a->font_w-6;
    if(mx>=close_x && mx<=close_x+a->font_w){ close_tab(a,idx); return; }

    a->active=idx;
}

void app_run(App *a){
    const int TARGET_FPS=60;
    const int FRAME_MS=1000/TARGET_FPS;
    const int BLINK_MS=530;

    while(a->running){
        uint32_t frame_start=SDL_GetTicks();

        /* ── events ── */
        SDL_Event ev;
        while(SDL_PollEvent(&ev)){
            switch(ev.type){
            case SDL_QUIT: a->running=false; break;

            case SDL_WINDOWEVENT:
                if(ev.window.event==SDL_WINDOWEVENT_RESIZED ||
                   ev.window.event==SDL_WINDOWEVENT_SIZE_CHANGED){
                    a->win_w=ev.window.data1;
                    a->win_h=ev.window.data2;
                    resize_all(a);
                }
                break;

            case SDL_KEYDOWN:
                handle_key(a,&ev.key);
                break;

            case SDL_TEXTINPUT: {
                Tab *t=a->tabs[a->active];
                pty_write(&t->pty,(uint8_t*)ev.text.text,(int)strlen(ev.text.text));
                break;
            }

            case SDL_MOUSEBUTTONDOWN: {
                int mx=ev.button.x, my=ev.button.y;
                Tab *t=a->tabs[a->active];
                if(my<a->tab_bar_h){
                    handle_tab_bar_click(a,mx);
                } else if(ev.button.button==SDL_BUTTON_LEFT){
                    int row,col;
                    screen_to_cell(a,mx,my,&row,&col);
                    t->sel_start_row=row; t->sel_start_col=col;
                    t->sel_end_row=row;   t->sel_end_col=col;
                    t->selecting=true; t->has_selection=false;
                } else if(ev.button.button==SDL_BUTTON_MIDDLE){
                    /* middle-click paste */
                    char *clip=SDL_GetClipboardText();
                    if(clip){ pty_write(&t->pty,(uint8_t*)clip,(int)strlen(clip)); SDL_free(clip); }
                }
                break;
            }

            case SDL_MOUSEBUTTONUP:
                if(ev.button.button==SDL_BUTTON_LEFT){
                    Tab *t=a->tabs[a->active];
                    t->selecting=false;
                    t->has_selection=
                        !(t->sel_start_row==t->sel_end_row &&
                          t->sel_start_col==t->sel_end_col);
                }
                break;

            case SDL_MOUSEMOTION: {
                Tab *t=a->tabs[a->active];
                if(t->selecting){
                    int row,col;
                    screen_to_cell(a,ev.motion.x,ev.motion.y,&row,&col);
                    t->sel_end_row=row; t->sel_end_col=col;
                }
                break;
            }

            case SDL_MOUSEWHEEL: {
                Tab *t=a->tabs[a->active];
                t->scroll_offset-=ev.wheel.y*3;
                if(t->scroll_offset<0) t->scroll_offset=0;
                int max=t->view_top;
                if(t->scroll_offset>max) t->scroll_offset=max;
                break;
            }
            }
        }

        /* ── read PTY ── */
        for(int i=0;i<a->ntabs;i++){
            Tab *t=a->tabs[i];
            if(t->alive) tab_poll(t);
            else if(i==a->active){ close_tab(a,i); break; }
        }

        /* ── cursor blink ── */
        uint32_t now=SDL_GetTicks();
        if(now-a->last_blink>=BLINK_MS){
            a->blink_on=!a->blink_on;
            a->last_blink=now;
        }

        /* ── render ── */
        render_frame(a);

        /* ── frame cap ── */
        int elapsed=(int)(SDL_GetTicks()-frame_start);
        if(elapsed<FRAME_MS) SDL_Delay(FRAME_MS-elapsed);
    }
}

int main(int argc, char **argv){
    (void)argc;(void)argv;
    App *a=app_create();
    if(!a) return 1;
    app_run(a);
    app_destroy(a);
    return 0;
}
