#include "terminal.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* ════════════════════════════════════════════════
   Linux / macOS  PTY
   ════════════════════════════════════════════════ */
#ifndef _WIN32

#include <pty.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <errno.h>

void pty_spawn(PtyHandle *p, const char *shell, int cols, int rows)
{
    struct winsize ws = {
        .ws_row = (unsigned short)rows,
        .ws_col = (unsigned short)cols,
        .ws_xpixel = 0, .ws_ypixel = 0
    };

    p->pid = forkpty(&p->master_fd, NULL, NULL, &ws);
    if (p->pid < 0) { perror("forkpty"); exit(1); }

    if (p->pid == 0) {
        /* child */
        const char *sh = shell ? shell : getenv("SHELL");
        if (!sh) sh = "/bin/sh";
        setenv("TERM", "xterm-256color", 1);
        setenv("COLORTERM", "truecolor", 1);
        execl(sh, sh, NULL);
        perror("execl"); _exit(1);
    }

    /* non-blocking reads */
    int flags = fcntl(p->master_fd, F_GETFL, 0);
    fcntl(p->master_fd, F_SETFL, flags | O_NONBLOCK);
}

void pty_resize(PtyHandle *p, int cols, int rows)
{
    struct winsize ws = {
        .ws_row = (unsigned short)rows,
        .ws_col = (unsigned short)cols,
        .ws_xpixel = 0, .ws_ypixel = 0
    };
    ioctl(p->master_fd, TIOCSWINSZ, &ws);
}

int pty_read(PtyHandle *p, uint8_t *buf, int bufsz)
{
    ssize_t n = read(p->master_fd, buf, bufsz);
    if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) return 0;
    return (int)n;
}

int pty_write(PtyHandle *p, const uint8_t *data, int len)
{
    return (int)write(p->master_fd, data, len);
}

void pty_close(PtyHandle *p)
{
    if (p->master_fd >= 0) close(p->master_fd);
    if (p->pid > 0) {
        kill(p->pid, SIGHUP);
        waitpid(p->pid, NULL, WNOHANG);
        p->pid = -1;
    }
}

/* ════════════════════════════════════════════════
   Windows  ConPTY
   ════════════════════════════════════════════════ */
#else  /* _WIN32 */

#ifndef ENABLE_VIRTUAL_TERMINAL_PROCESSING
#define ENABLE_VIRTUAL_TERMINAL_PROCESSING 0x0004
#endif

void pty_spawn(PtyHandle *p, const char *shell, int cols, int rows)
{
    memset(p, 0, sizeof(*p));

    /* create anonymous pipes */
    HANDLE hPipeInRead,  hPipeInWrite;
    HANDLE hPipeOutRead, hPipeOutWrite;
    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
    CreatePipe(&hPipeInRead,  &hPipeInWrite,  &sa, 0);
    CreatePipe(&hPipeOutRead, &hPipeOutWrite, &sa, 0);

    /* create ConPTY */
    COORD size = { (SHORT)cols, (SHORT)rows };
    HRESULT hr = CreatePseudoConsole(size, hPipeInRead, hPipeOutWrite,
                                     0, &p->hPcon);
    if (FAILED(hr)) { fprintf(stderr, "CreatePseudoConsole failed\n"); exit(1); }
    CloseHandle(hPipeInRead);
    CloseHandle(hPipeOutWrite);

    p->hPipeIn  = hPipeInWrite;   /* we write  → child reads  */
    p->hPipeOut = hPipeOutRead;   /* we read   ← child writes */

    /* build STARTUPINFOEX */
    SIZE_T attrListSize = 0;
    InitializeProcThreadAttributeList(NULL, 1, 0, &attrListSize);
    LPPROC_THREAD_ATTRIBUTE_LIST attrList =
        (LPPROC_THREAD_ATTRIBUTE_LIST)HeapAlloc(GetProcessHeap(), 0, attrListSize);
    InitializeProcThreadAttributeList(attrList, 1, 0, &attrListSize);
    UpdateProcThreadAttribute(attrList, 0,
        PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE, p->hPcon,
        sizeof(p->hPcon), NULL, NULL);

    STARTUPINFOEXW si = {0};
    si.StartupInfo.cb = sizeof(si);
    si.lpAttributeList = attrList;

    /* determine shell */
    const char *sh = shell ? shell : "cmd.exe";
    int wlen = MultiByteToWideChar(CP_UTF8, 0, sh, -1, NULL, 0);
    WCHAR *wsh = (WCHAR *)_alloca(wlen * sizeof(WCHAR));
    MultiByteToWideChar(CP_UTF8, 0, sh, -1, wsh, wlen);

    PROCESS_INFORMATION pi = {0};
    if (!CreateProcessW(NULL, wsh, NULL, NULL, FALSE,
                        EXTENDED_STARTUPINFO_PRESENT, NULL, NULL,
                        &si.StartupInfo, &pi))
    {
        fprintf(stderr, "CreateProcess failed: %lu\n", GetLastError());
        exit(1);
    }

    p->hProcess = pi.hProcess;
    p->hThread  = pi.hThread;
    DeleteProcThreadAttributeList(attrList);
    HeapFree(GetProcessHeap(), 0, attrList);
}

void pty_resize(PtyHandle *p, int cols, int rows)
{
    COORD size = { (SHORT)cols, (SHORT)rows };
    ResizePseudoConsole(p->hPcon, size);
}

int pty_read(PtyHandle *p, uint8_t *buf, int bufsz)
{
    DWORD avail = 0;
    if (!PeekNamedPipe(p->hPipeOut, NULL, 0, NULL, &avail, NULL)) return -1;
    if (avail == 0) return 0;
    DWORD n = 0;
    ReadFile(p->hPipeOut, buf, (DWORD)bufsz < avail ? (DWORD)bufsz : avail, &n, NULL);
    return (int)n;
}

int pty_write(PtyHandle *p, const uint8_t *data, int len)
{
    DWORD written = 0;
    WriteFile(p->hPipeIn, data, (DWORD)len, &written, NULL);
    return (int)written;
}

void pty_close(PtyHandle *p)
{
    TerminateProcess(p->hProcess, 0);
    CloseHandle(p->hProcess);
    CloseHandle(p->hThread);
    CloseHandle(p->hPipeIn);
    CloseHandle(p->hPipeOut);
    ClosePseudoConsole(p->hPcon);
}

#endif /* _WIN32 */
