#include "terminal.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

/* ── helpers ── */
static inline uint32_t argb(uint8_t a,uint8_t r,uint8_t g,uint8_t b){
    return ((uint32_t)a<<24)|((uint32_t)r<<16)|((uint32_t)g<<8)|b;
}

void vt_init(VTParser *p) { memset(p, 0, sizeof(*p)); }

/* ── default cell ── */
static void default_attr(CellAttr *a){
    a->fg = COL_FG; a->bg = 0; /* 0 = use default bg */
    a->bold=a->italic=a->underline=a->blink=a->reverse=a->invisible=false;
}

/* ────────────────────────────────────────────────
   Screen helpers
   ──────────────────────────────────────────────── */

/* Pointer to a line (absolute index in lines[]) */
static Row *get_line(Tab *t, int abs){
    if(abs<0||abs>=t->total_lines) return NULL;
    return &t->lines[abs];
}

/* Absolute index of viewport row r */
static int abs_row(Tab *t, int r){ return t->view_top + r; }

/* Get cell for viewport (row,col), NULL if OOB */
static Cell *get_cell(Tab *t,int r,int c){
    if(r<0||r>=t->rows||c<0||c>=t->cols) return NULL;
    Row *row=get_line(t,abs_row(t,r));
    return row?&row->cells[c]:NULL;
}

static void put_cell(Tab *t,int r,int c,uint32_t cp,const CellAttr *a){
    Cell *cell=get_cell(t,r,c);
    if(!cell)return;
    cell->codepoint=cp;
    cell->attr=*a;
    cell->dirty=true;
}

/* Erase rect */
static void erase_region(Tab *t,int r0,int c0,int r1,int c1){
    for(int r=r0;r<=r1&&r<t->rows;r++)
        for(int c=c0;c<=c1&&c<t->cols;c++){
            Cell *cell=get_cell(t,r,c);
            if(!cell)continue;
            cell->codepoint=' ';
            default_attr(&cell->attr);
            cell->dirty=true;
        }
}

/* Scroll viewport up by n lines (add new blank lines at bottom) */
static void scroll_up(Tab *t,int top,int bot,int n){
    for(int i=0;i<n;i++){
        /* push view_top forward if we're at scrollback limit */
        int free_below=(t->total_lines-1)-(t->view_top+t->rows-1);
        if(free_below>0){
            /* shift rows in [top,bot] up by 1 */
            for(int r=top;r<bot;r++){
                Row *dst=get_line(t,abs_row(t,r));
                Row *src=get_line(t,abs_row(t,r+1));
                if(dst&&src) *dst=*src;
            }
            /* blank the bottom row */
            Row *bot_row=get_line(t,abs_row(t,bot));
            if(bot_row){
                memset(bot_row->cells,0,sizeof(bot_row->cells));
                for(int c=0;c<t->cols;c++){
                    bot_row->cells[c].codepoint=' ';
                    default_attr(&bot_row->cells[c].attr);
                    bot_row->cells[c].dirty=true;
                }
                bot_row->soft_wrap=false;
            }
            /* If scrolling full screen, grow view_top */
            if(top==0&&bot==t->rows-1) t->view_top++;
        }
    }
}

static void scroll_down(Tab *t,int top,int bot,int n){
    for(int i=0;i<n;i++){
        for(int r=bot;r>top;r--){
            Row *dst=get_line(t,abs_row(t,r));
            Row *src=get_line(t,abs_row(t,r-1));
            if(dst&&src) *dst=*src;
        }
        Row *top_row=get_line(t,abs_row(t,top));
        if(top_row){
            for(int c=0;c<t->cols;c++){
                top_row->cells[c].codepoint=' ';
                default_attr(&top_row->cells[c].attr);
                top_row->cells[c].dirty=true;
            }
            top_row->soft_wrap=false;
        }
    }
}

/* ── Cursor movement ── */
static void cursor_clamp(Tab *t){
    if(t->cur_row<0)t->cur_row=0;
    if(t->cur_col<0)t->cur_col=0;
    if(t->cur_row>=t->rows)t->cur_row=t->rows-1;
    if(t->cur_col>=t->cols)t->cur_col=t->cols-1;
}

/* ── Newline ── */
static void do_newline(Tab *t){
    if(t->cur_row>=t->scroll_bot){
        scroll_up(t,t->scroll_top,t->scroll_bot,1);
    } else {
        t->cur_row++;
    }
}

/* ════════════════════════════════════════════════
   SGR (colours / attributes)
   ════════════════════════════════════════════════ */
static void apply_sgr(Tab *t, int *params, int n){
    if(n==0){ default_attr(&t->cur_attr); return; }
    int i=0;
    while(i<n){
        int p=params[i++];
        switch(p){
        case 0:  default_attr(&t->cur_attr); break;
        case 1:  t->cur_attr.bold=true;  break;
        case 3:  t->cur_attr.italic=true; break;
        case 4:  t->cur_attr.underline=true; break;
        case 5:  t->cur_attr.blink=true; break;
        case 7:  t->cur_attr.reverse=true; break;
        case 8:  t->cur_attr.invisible=true; break;
        case 22: t->cur_attr.bold=false; break;
        case 23: t->cur_attr.italic=false; break;
        case 24: t->cur_attr.underline=false; break;
        case 25: t->cur_attr.blink=false; break;
        case 27: t->cur_attr.reverse=false; break;
        case 28: t->cur_attr.invisible=false; break;
        /* fg 30-37 */
        case 30: case 31: case 32: case 33:
        case 34: case 35: case 36: case 37:
            t->cur_attr.fg=ANSI_PALETTE[p-30]; break;
        case 38: /* 256 / true colour fg */
            if(i<n && params[i]==5 && i+1<n){
                t->cur_attr.fg=ANSI_PALETTE[params[i+1]%16]; i+=2;
            } else if(i<n && params[i]==2 && i+3<n){
                t->cur_attr.fg=argb(0xFF,params[i+1],params[i+2],params[i+3]); i+=4;
            } break;
        case 39: t->cur_attr.fg=COL_FG; break;
        /* bg 40-47 */
        case 40: case 41: case 42: case 43:
        case 44: case 45: case 46: case 47:
            t->cur_attr.bg=ANSI_PALETTE[p-40]; break;
        case 48: /* 256 / true colour bg */
            if(i<n && params[i]==5 && i+1<n){
                t->cur_attr.bg=ANSI_PALETTE[params[i+1]%16]; i+=2;
            } else if(i<n && params[i]==2 && i+3<n){
                t->cur_attr.bg=argb(0xFF,params[i+1],params[i+2],params[i+3]); i+=4;
            } break;
        case 49: t->cur_attr.bg=0; break;
        /* bright fg 90-97 */
        case 90: case 91: case 92: case 93:
        case 94: case 95: case 96: case 97:
            t->cur_attr.fg=ANSI_PALETTE[8+(p-90)]; break;
        /* bright bg 100-107 */
        case 100: case 101: case 102: case 103:
        case 104: case 105: case 106: case 107:
            t->cur_attr.bg=ANSI_PALETTE[8+(p-100)]; break;
        }
    }
}

/* ════════════════════════════════════════════════
   CSI dispatch
   ════════════════════════════════════════════════ */
static int P(VTParser *p,int i,int def){
    return (i<p->nparams && p->params[i]>0)?p->params[i]:def;
}

static void csi_dispatch(Tab *t, VTParser *p, char final){
    int *pm=p->params; int n=p->nparams;
    switch(final){
    case 'A': t->cur_row-=P(p,0,1); cursor_clamp(t); break;
    case 'B': t->cur_row+=P(p,0,1); cursor_clamp(t); break;
    case 'C': t->cur_col+=P(p,0,1); cursor_clamp(t); break;
    case 'D': t->cur_col-=P(p,0,1); cursor_clamp(t); break;
    case 'E': t->cur_row+=P(p,0,1); t->cur_col=0; cursor_clamp(t); break;
    case 'F': t->cur_row-=P(p,0,1); t->cur_col=0; cursor_clamp(t); break;
    case 'G': t->cur_col=P(p,0,1)-1; cursor_clamp(t); break;
    case 'H': case 'f':
        t->cur_row=P(p,0,1)-1; t->cur_col=P(p,1,1)-1; cursor_clamp(t); break;
    case 'J': {
        int m=P(p,0,0);
        if(m==0) erase_region(t,t->cur_row,t->cur_col,t->rows-1,t->cols-1);
        else if(m==1) erase_region(t,0,0,t->cur_row,t->cur_col);
        else if(m==2||m==3) erase_region(t,0,0,t->rows-1,t->cols-1);
        break;
    }
    case 'K': {
        int m=P(p,0,0);
        if(m==0) erase_region(t,t->cur_row,t->cur_col,t->cur_row,t->cols-1);
        else if(m==1) erase_region(t,t->cur_row,0,t->cur_row,t->cur_col);
        else if(m==2) erase_region(t,t->cur_row,0,t->cur_row,t->cols-1);
        break;
    }
    case 'L': scroll_down(t,t->cur_row,t->scroll_bot,P(p,0,1)); break;
    case 'M': scroll_up(t,t->cur_row,t->scroll_bot,P(p,0,1)); break;
    case 'P': { /* delete chars */
        int cnt=P(p,0,1);
        int r=t->cur_row, c=t->cur_col, cols=t->cols;
        for(int i=c;i<cols-cnt;i++){
            Cell *dst=get_cell(t,r,i);
            Cell *src=get_cell(t,r,i+cnt);
            if(dst&&src)*dst=*src;
        }
        for(int i=cols-cnt;i<cols;i++){
            Cell *cell=get_cell(t,r,i);
            if(cell){ cell->codepoint=' '; default_attr(&cell->attr); cell->dirty=true; }
        }
        break;
    }
    case '@': { /* insert chars */
        int cnt=P(p,0,1);
        int r=t->cur_row, c=t->cur_col, cols=t->cols;
        for(int i=cols-1;i>=c+cnt;i--){
            Cell *dst=get_cell(t,r,i);
            Cell *src=get_cell(t,r,i-cnt);
            if(dst&&src)*dst=*src;
        }
        erase_region(t,r,c,r,c+cnt-1);
        break;
    }
    case 'S': scroll_up(t,t->scroll_top,t->scroll_bot,P(p,0,1)); break;
    case 'T': scroll_down(t,t->scroll_top,t->scroll_bot,P(p,0,1)); break;
    case 'd': t->cur_row=P(p,0,1)-1; cursor_clamp(t); break;
    case 'h': /* set mode */
        if(p->priv=='?'){
            int v=P(p,0,0);
            if(v==25) t->cur_visible=true;
            if(v==1049){ /* alt screen: simple */
                t->mode_alt_screen=true;
            }
        }
        break;
    case 'l':
        if(p->priv=='?'){
            int v=P(p,0,0);
            if(v==25) t->cur_visible=false;
            if(v==1049){
                t->mode_alt_screen=false;
            }
        }
        break;
    case 'm': apply_sgr(t,pm,n); break;
    case 'r': /* DECSTBM */
        t->scroll_top=P(p,0,1)-1;
        t->scroll_bot=P(p,1,t->rows)-1;
        if(t->scroll_top<0)t->scroll_top=0;
        if(t->scroll_bot>=t->rows)t->scroll_bot=t->rows-1;
        t->cur_row=0; t->cur_col=0;
        break;
    case 's': t->saved_row=t->cur_row; t->saved_col=t->cur_col; t->saved_attr=t->cur_attr; break;
    case 'u': t->cur_row=t->saved_row; t->cur_col=t->saved_col; t->cur_attr=t->saved_attr; break;
    case 'n': /* DSR */
        if(P(p,0,0)==6){
            char resp[32];
            int len=snprintf(resp,sizeof(resp),"\x1b[%d;%dR",t->cur_row+1,t->cur_col+1);
            pty_write(&t->pty,(uint8_t*)resp,len);
        }
        break;
    case 'X': erase_region(t,t->cur_row,t->cur_col,t->cur_row,t->cur_col+P(p,0,1)-1); break;
    default: break;
    }
}

/* ════════════════════════════════════════════════
   Main VT processor  (one byte at a time)
   ════════════════════════════════════════════════ */
void vt_process(Tab *t, uint8_t c)
{
    VTParser *p=&t->parser;

    /* ── UTF-8 multi-byte accumulation ── */
    if(p->state==PS_UTF8){
        if((c&0xC0)==0x80){
            p->utf8_acc=(p->utf8_acc<<6)|(c&0x3F);
            p->utf8_need--;
            if(p->utf8_need==0){
                /* emit codepoint */
                uint32_t cp=p->utf8_acc;
                put_cell(t,t->cur_row,t->cur_col,cp,&t->cur_attr);
                t->cur_col++;
                if(t->cur_col>=t->cols){
                    if(t->mode_auto_wrap){
                        Row *row=get_line(t,abs_row(t,t->cur_row));
                        if(row) row->soft_wrap=true;
                        t->cur_col=0;
                        do_newline(t);
                    } else {
                        t->cur_col=t->cols-1;
                    }
                }
                p->state=PS_GROUND;
            }
        } else {
            p->state=PS_GROUND; /* invalid, fall through */
        }
        if(p->state==PS_UTF8) return;
    }

    /* ── C0 controls (always processed in ground & most states) ── */
    if(c<0x20){
        switch(c){
        case '\r': t->cur_col=0; return;
        case '\n': case '\x0B': case '\x0C':
            do_newline(t);
            return;
        case '\t': {
            int next_tab=((t->cur_col/8)+1)*8;
            if(next_tab>=t->cols) next_tab=t->cols-1;
            t->cur_col=next_tab;
            return;
        }
        case '\b':
            if(t->cur_col>0) t->cur_col--;
            return;
        case 0x07: /* BEL – ignore */ return;
        case 0x0E: case 0x0F: return; /* SO/SI charset */
        case 0x1B: /* ESC */
            p->state=PS_ESC;
            p->nparams=0; p->ninter=0; p->priv=0;
            return;
        default: return;
        }
    }

    switch(p->state){
    /* ── GROUND ── */
    case PS_GROUND:
        if(c>=0x80){
            /* UTF-8 start byte */
            if((c&0xE0)==0xC0){ p->utf8_acc=c&0x1F; p->utf8_need=1; p->state=PS_UTF8; return; }
            if((c&0xF0)==0xE0){ p->utf8_acc=c&0x0F; p->utf8_need=2; p->state=PS_UTF8; return; }
            if((c&0xF8)==0xF0){ p->utf8_acc=c&0x07; p->utf8_need=3; p->state=PS_UTF8; return; }
            return;
        }
        /* printable ASCII */
        put_cell(t,t->cur_row,t->cur_col,c,&t->cur_attr);
        t->cur_col++;
        if(t->cur_col>=t->cols){
            if(t->mode_auto_wrap){
                Row *row=get_line(t,abs_row(t,t->cur_row));
                if(row) row->soft_wrap=true;
                t->cur_col=0;
                do_newline(t);
            } else {
                t->cur_col=t->cols-1;
            }
        }
        break;

    /* ── ESC ── */
    case PS_ESC:
        switch(c){
        case '[': p->state=PS_CSI; return;
        case ']': p->state=PS_OSC; p->osc_len=0; return;
        case 'P': p->state=PS_DCS; return;
        case 'D': do_newline(t); break;         /* IND */
        case 'M':                                /* RI  */
            if(t->cur_row<=t->scroll_top) scroll_down(t,t->scroll_top,t->scroll_bot,1);
            else t->cur_row--;
            break;
        case 'E': t->cur_col=0; do_newline(t); break;  /* NEL */
        case '7': t->saved_row=t->cur_row; t->saved_col=t->cur_col; t->saved_attr=t->cur_attr; break;
        case '8': t->cur_row=t->saved_row; t->cur_col=t->saved_col; t->cur_attr=t->saved_attr; break;
        case 'c': /* RIS */
            erase_region(t,0,0,t->rows-1,t->cols-1);
            t->cur_row=0; t->cur_col=0;
            default_attr(&t->cur_attr);
            break;
        default: break;
        }
        p->state=PS_GROUND;
        break;

    /* ── CSI ── */
    case PS_CSI:
        if(c>='0'&&c<='9'){
            if(p->nparams==0) p->nparams=1;
            p->params[p->nparams-1]=p->params[p->nparams-1]*10+(c-'0');
        } else if(c==';'){
            if(p->nparams<MAX_PARAMS){ p->nparams++; p->params[p->nparams-1]=0; }
        } else if(c>='<'&&c<='?'){
            p->priv=c;
        } else if(c>='@'&&c<='~'){
            if(p->nparams==0&&!p->priv) p->nparams=0; /* no params */
            csi_dispatch(t,p,c);
            p->state=PS_GROUND;
            p->nparams=0; p->ninter=0; p->priv=0;
        }
        break;

    /* ── OSC ── */
    case PS_OSC:
        if(c==0x07||(c==0x5C&&p->osc_len>0&&p->osc_buf[p->osc_len-1]==0x1B)){
            /* end: parse OSC (0;title / 2;title) */
            p->osc_buf[p->osc_len]='\0';
            if(p->osc_len>2 && (p->osc_buf[0]=='0'||p->osc_buf[0]=='2') && p->osc_buf[1]==';'){
                snprintf(t->title, sizeof(t->title), "%s", p->osc_buf+2);
            }
            p->state=PS_GROUND;
        } else if(p->osc_len<MAX_OSC-1){
            p->osc_buf[p->osc_len++]=(char)c;
        }
        break;

    /* ── DCS – just consume until ST ── */
    case PS_DCS:
        if(c==0x5C) p->state=PS_GROUND;
        break;

    default:
        p->state=PS_GROUND;
        break;
    }
}
