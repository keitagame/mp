#include "terminal.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/* ── colour helpers ── */
static void set_color(SDL_Renderer *r, uint32_t argb){
    SDL_SetRenderDrawColor(r,
        (argb>>16)&0xFF, (argb>>8)&0xFF, argb&0xFF, (argb>>24)&0xFF);
}

/* ── render one Unicode glyph (ASCII fast path + SDL_ttf) ── */
static void render_glyph(App *a, uint32_t cp, int x, int y,
                          uint32_t fg, bool bold, bool underline)
{
    TTF_Font *font = bold ? a->font_bold : a->font;
    if(!font) return;

    SDL_Color col = {
        (fg>>16)&0xFF, (fg>>8)&0xFF, fg&0xFF, 0xFF
    };

    /* render single codepoint */
    char utf8[5]={0};
    if(cp<0x80){
        utf8[0]=(char)cp;
    } else if(cp<0x800){
        utf8[0]=(char)(0xC0|(cp>>6));
        utf8[1]=(char)(0x80|(cp&0x3F));
    } else if(cp<0x10000){
        utf8[0]=(char)(0xE0|(cp>>12));
        utf8[1]=(char)(0x80|((cp>>6)&0x3F));
        utf8[2]=(char)(0x80|(cp&0x3F));
    } else {
        utf8[0]=(char)(0xF0|(cp>>18));
        utf8[1]=(char)(0x80|((cp>>12)&0x3F));
        utf8[2]=(char)(0x80|((cp>>6)&0x3F));
        utf8[3]=(char)(0x80|(cp&0x3F));
    }

    SDL_Surface *surf = TTF_RenderUTF8_Blended(font, utf8, col);
    if(!surf) return;
    SDL_Texture *tex = SDL_CreateTextureFromSurface(a->ren, surf);
    SDL_FreeSurface(surf);
    if(!tex) return;

    int tw,th;
    SDL_QueryTexture(tex,NULL,NULL,&tw,&th);
    SDL_Rect dst={x, y, tw<a->font_w*2?a->font_w:a->font_w*2, a->font_h};
    SDL_RenderCopy(a->ren, tex, NULL, &dst);
    SDL_DestroyTexture(tex);

    if(underline){
        set_color(a->ren, 0xFFF8F8F2);
        SDL_Rect ul={x, y+a->font_h-2, a->font_w, 1};
        SDL_RenderFillRect(a->ren,&ul);
    }
}

/* ── render text label (ASCII only) ── */
static void render_text(App *a, const char *s, int x, int y, uint32_t fg){
    while(*s){
        render_glyph(a,(uint8_t)*s,x,y,fg,false,false);
        x+=a->font_w;
        s++;
    }
}

/* ── tab bar ── */
static void render_tab_bar(App *a){
    SDL_Renderer *r=a->ren;
    int h=a->tab_bar_h;
    /* background */
    set_color(r, COL_TAB_INACT);
    SDL_Rect bar={0,0,a->win_w,h};
    SDL_RenderFillRect(r,&bar);

    int tab_w=a->win_w/a->ntabs;
    if(tab_w>200) tab_w=200;

    for(int i=0;i<a->ntabs;i++){
        Tab *t=a->tabs[i];
        int x=i*tab_w, tw=tab_w-1;
        SDL_Rect bg={x,0,tw,h};
        set_color(r, i==a->active ? COL_TAB_ACT : COL_TAB_INACT);
        SDL_RenderFillRect(r,&bg);

        /* active indicator */
        if(i==a->active){
            set_color(r, COL_BORDER);
            SDL_Rect ind={x,h-2,tw,2};
            SDL_RenderFillRect(r,&ind);
        }

        /* title */
        char label[32];
        snprintf(label,sizeof(label),"%d: %.16s",i+1,t->title[0]?t->title:"bash");
        render_text(a,label,x+6,4,COL_TAB_TEXT);

        /* close button */
        render_text(a,"×",x+tw-a->font_w-6,4,0xFFFF5555);
    }

    /* "+" new tab button */
    int nx=a->ntabs*tab_w;
    render_text(a,"+",nx+6,4,0xFF50FA7B);
}

/* ── scrollbar ── */
static void render_scrollbar(App *a, Tab *t){
    SDL_Renderer *r=a->ren;
    int sbw=10;
    int area_h=a->win_h-a->tab_bar_h;
    int x=a->win_w-sbw;
    int y=a->tab_bar_h;

    /* track */
    set_color(r,0xFF21222C);
    SDL_Rect track={x,y,sbw,area_h};
    SDL_RenderFillRect(r,&track);

    /* total scrollable lines */
    int total=t->view_top+t->rows; /* rough */
    if(total<=t->rows) return;
    float ratio=(float)t->rows/total;
    int thumb_h=(int)(area_h*ratio);
    if(thumb_h<20) thumb_h=20;

    float scroll_frac=(total-t->rows-t->scroll_offset)/(float)(total-t->rows+1);
    int thumb_y=y+(int)((area_h-thumb_h)*scroll_frac);

    set_color(r,0xFF6272A4);
    SDL_Rect thumb={x+2,thumb_y,sbw-4,thumb_h};
    SDL_RenderFillRect(r,&thumb);
}

/* ── main cell renderer ── */
static void render_cells(App *a, Tab *t){
    SDL_Renderer *r=a->ren;
    int x0=a->padding, y0=a->tab_bar_h+a->padding;
    int fw=a->font_w, fh=a->font_h;

    for(int row=0;row<t->rows;row++){
        int abs=t->view_top+row-t->scroll_offset;
        if(abs<0||abs>=t->total_lines) continue;
        Row *line=&t->lines[abs];

        for(int col=0;col<t->cols;col++){
            Cell *cell=&line->cells[col];
            int px=x0+col*fw;
            int py=y0+row*fh;

            uint32_t fg=cell->attr.fg ? cell->attr.fg : COL_FG;
            uint32_t bg=cell->attr.bg ? cell->attr.bg : (uint32_t)COL_BG;

            if(cell->attr.reverse){ uint32_t tmp=fg; fg=bg; bg=tmp; }
            if(cell->attr.invisible) fg=bg;

            /* background */
            set_color(r,bg|0xFF000000);
            SDL_Rect bgr={px,py,fw,fh};
            SDL_RenderFillRect(r,&bgr);

            /* selection highlight */
            if(t->has_selection){
                bool in_sel=false;
                int sr=t->sel_start_row, sc=t->sel_start_col;
                int er=t->sel_end_row,   ec=t->sel_end_col;
                if(sr>er||(sr==er&&sc>ec)){
                    int tr=sr,tc=sc; sr=er;sc=ec; er=tr;ec=tc;
                }
                if(row>sr||(row==sr&&col>=sc))
                  if(row<er||(row==er&&col<=ec))
                    in_sel=true;
                if(in_sel){
                    set_color(r,COL_SEL|0xFF000000);
                    SDL_RenderFillRect(r,&bgr);
                }
            }

            /* glyph */
            uint32_t cp=cell->codepoint;
            if(cp && cp!=' '){
                render_glyph(a,cp,px,py,fg,cell->attr.bold,cell->attr.underline);
            }
        }
    }

    /* cursor */
    if(t->cur_visible && t->scroll_offset==0){
        int px=x0+t->cur_col*fw;
        int py=y0+t->cur_row*fh;
        uint32_t cc=a->blink_on ? COL_CURSOR : 0;
        if(cc){
            set_color(r,cc);
            SDL_Rect cbox={px,py,fw,fh};
            SDL_RenderFillRect(r,&cbox);
            /* draw char under cursor inverted */
            Cell *cc_cell=get_cell_pub(t,t->cur_row,t->cur_col);
            if(cc_cell && cc_cell->codepoint && cc_cell->codepoint!=' '){
                render_glyph(a,cc_cell->codepoint,px,py,COL_BG,cc_cell->attr.bold,false);
            }
        } else {
            /* hollow cursor */
            set_color(r,COL_CURSOR);
            SDL_Rect cbox={px,py,fw,fh};
            SDL_RenderDrawRect(r,&cbox);
        }
    }
}

void render_frame(App *a){
    Tab *t=a->tabs[a->active];
    SDL_Renderer *r=a->ren;

    /* background */
    set_color(r,COL_BG);
    SDL_RenderClear(r);

    render_tab_bar(a);
    render_cells(a,t);
    render_scrollbar(a,t);

    SDL_RenderPresent(r);
}
